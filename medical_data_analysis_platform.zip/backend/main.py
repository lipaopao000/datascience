import os
import tempfile
import shutil
from typing import Dict, Any, List, Optional # Moved Optional here

from fastapi import FastAPI, HTTPException, UploadFile, File, APIRouter, Depends, Query # Moved Query here
from fastapi.middleware.cors import CORSMiddleware

from services.data_processor import DataProcessor
from services.feature_extractor import FeatureExtractor
from services.ml_service import MLService
from services.data_cleaner import DataCleaner
from services.enhanced_data_cleaner import EnhancedDataCleaner
from models.schemas import (
    DataUploadResponse,
    GenericDataResponse,
    FeatureExtractionRequest,
    MLTrainRequest,
    MLPredictRequest,
    DataSchemaCreate, 
    DataSchemaResponse,
    DataSchemaUpdate,
    DataConfirmRequest,
    ConfirmedDataResponse,
    DataFormatRequest,
    DataFormatResponse,
    DataDeleteBatchRequest, # New import
    DataDeleteBatchResponse # New import
)
from services.schema_service import SchemaService
from routers import schema_router # Import the router object

app = FastAPI(title="医疗数据分析平台", version="1.0.0")

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化服务
# 先创建实例，暂不传入相互依赖
data_processor = DataProcessor()
feature_extractor = FeatureExtractor()
ml_service = MLService()
data_cleaner = DataCleaner()
enhanced_cleaner = EnhancedDataCleaner()
schema_service = SchemaService(data_processor_instance=None) # Initialize with None for now

# 注入相互依赖
data_processor.schema_service = schema_service
schema_service.data_processor = data_processor

# 确保数据目录存在
os.makedirs("data/processed", exist_ok=True)
os.makedirs("data/features", exist_ok=True)
os.makedirs("data/models", exist_ok=True)
os.makedirs("data/schemas", exist_ok=True) # Ensure schemas directory exists

# Set the schema_service instance for the router's dependency
schema_router._schema_service_instance = schema_service

# Include schema router
app.include_router(schema_router.router, prefix="/api/schemas", tags=["Schemas"])

@app.get("/")
async def root():
    return {"message": "医疗数据分析平台 API"}

@app.post("/api/upload", response_model=DataUploadResponse)
async def upload_data(
    files: List[UploadFile] = File(...),
    group_name: Optional[str] = Query(None, description="可选的数据分组名称")
):
    """上传数据文件（ZIP或CSV）"""
    total_patient_count = 0
    all_file_info = []

    try:
        for file in files:
            # 创建临时目录
            with tempfile.TemporaryDirectory() as temp_dir:
                file_path = os.path.join(temp_dir, file.filename)

                # 保存上传的文件
                with open(file_path, "wb") as buffer:
                    shutil.copyfileobj(file.file, buffer)

                # 处理数据
                if file.filename.endswith('.zip'):
                    result = await data_processor.process_zip_file(file_path, group_name=group_name)
                elif file.filename.endswith('.csv'):
                    result = await data_processor.process_csv_file(file_path, group_name=group_name)
                else:
                    raise HTTPException(status_code=400, detail=f"不支持的文件格式: {file.filename}")
                
                total_patient_count += result["patient_count"]
                file_info_entry = {
                    "file_name": file.filename,
                    **result["file_info"]
                }
                if group_name:
                    file_info_entry["group_name"] = group_name
                all_file_info.append(file_info_entry)

        return DataUploadResponse(
            success=True,
            message=f"成功处理 {len(files)} 个文件",
            patient_count=total_patient_count,
            file_info={"uploaded_files_summary": all_file_info}
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据处理失败: {str(e)}")


@app.get("/api/data") # Renamed endpoint
async def get_data_list(): # Renamed function
    """获取所有数据ID列表"""
    try:
        data_ids = data_processor.get_patient_list() # get_patient_list now returns data_ids
        
        # Simplified response, no longer trying to load patients_info.json
        # Frontend will need to adapt to this simpler list of IDs
        return {"data_ids": data_ids}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取数据ID列表失败: {str(e)}")


@app.get("/api/data/{data_id}", response_model=GenericDataResponse) # Renamed endpoint and response model
async def get_data_details(data_id: str): # Renamed function and parameter
    """获取特定数据的数据详情"""
    try:
        data = data_processor.get_patient_data(data_id) # get_patient_data now returns generic data
        if not data:
            raise HTTPException(status_code=404, detail="数据未找到")

        return GenericDataResponse( # Use new schema
            data_id=data["data_id"],
            columns=data["columns"],
            data=data["data"],
            shape=data["shape"],
            summary=data["summary"],
            records=data["records"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取数据详情失败: {str(e)}")


@app.post("/api/clean/{data_id}") # Renamed parameter
async def clean_data(data_id: str, cleaning_config: Dict[str, Any]): # Renamed parameter
    """清洗数据"""
    try:
        # Note: DataCleaner and EnhancedDataCleaner might still use 'patient_id' internally.
        # This would require further refactoring if cleaning needs to be fully generic.
        result = await data_cleaner.clean_patient_data(data_id, cleaning_config)
        return {"success": True, "message": "数据清洗完成", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据清洗失败: {str(e)}")


@app.post("/api/features/extract")
async def extract_features(request: FeatureExtractionRequest): # Updated request schema
    """提取特征"""
    try:
        features = await feature_extractor.extract_features(
            data_id=request.data_id, # Updated parameter
            feature_config=request.feature_config # Updated parameter
        )
        return {"success": True, "features": features}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"特征提取失败: {str(e)}")


@app.get("/api/features")
async def get_all_features(): # Renamed function for clarity
    """获取所有已提取的特征"""
    try:
        features = feature_extractor.get_feature_table() # Now gets all features
        return {"features": features}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取特征失败: {str(e)}")

@app.get("/api/features/{data_id}") # New endpoint for specific data_id features
async def get_features_for_data_id(data_id: str):
    """获取特定数据ID的已提取特征"""
    try:
        features = feature_extractor.get_feature_table(data_id=data_id)
        return {"features": features}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取 {data_id} 的特征失败: {str(e)}")


@app.post("/api/ml/train")
async def train_model(request: MLTrainRequest):
    """训练机器学习模型"""
    try:
        result = await ml_service.train_model(
            data_id=request.data_id, # Pass data_id
            model_type=request.model_type,
            features=request.features,
            target=request.target,
            model_params=request.model_params
        )
        # The train_model in ml_service now returns training_history as well
        return {
            "success": True, 
            "model_id": result["model_id"], 
            "metrics": result["metrics"],
            "training_history": result["training_history"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"模型训练失败: {str(e)}")


@app.post("/api/ml/predict")
async def predict(request: MLPredictRequest):
    """使用模型进行预测"""
    try:
        predictions = await ml_service.predict(
            model_id=request.model_id,
            features=request.features
        )
        return {"success": True, "predictions": predictions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"预测失败: {str(e)}")


@app.get("/api/ml/models")
async def get_models():
    """获取所有训练的模型"""
    try:
        models = ml_service.get_model_list()
        return {"models": models}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型列表失败: {str(e)}")

@app.get("/api/ml/models/{model_id}/history")
async def get_model_training_history(model_id: str):
    """获取特定模型的训练历史（例如损失曲线数据）"""
    try:
        history = ml_service.get_training_history(model_id)
        return {"model_id": model_id, "training_history": history}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取模型训练历史失败: {str(e)}")


@app.get("/api/visualize/{data_id}") # Renamed endpoint and parameter
async def get_visualization_data(data_id: str): # Removed data_type parameter
    """获取可视化数据"""
    try:
        viz_data = data_processor.get_visualization_data(data_id) # Removed data_type parameter
        return {"data": viz_data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取可视化数据失败: {str(e)}")


@app.post("/api/data/{data_id}/analyze-quality") # Renamed endpoint and parameter
async def analyze_data_quality(data_id: str): # Renamed parameter
    """分析数据质量"""
    try:
        # 加载数据
        data = data_processor.load_patient_data(data_id) # load_patient_data now loads generic data
        if not data:
            raise HTTPException(status_code=404, detail="数据未找到")

        # 分析数据质量
        quality_report = enhanced_cleaner.analyze_data_quality(data) # Pass generic data

        return {"quality_report": quality_report}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据质量分析失败: {str(e)}")


@app.post("/api/data/{data_id}/preview-cleaning") # Renamed endpoint and parameter
async def preview_cleaning_effect(data_id: str, config: dict): # Renamed parameter
    """预览清洗效果"""
    try:
        # 加载数据
        data = data_processor.load_patient_data(data_id) # load_patient_data now loads generic data
        if not data:
            raise HTTPException(status_code=404, detail="数据未找到")

        column = config.get('column')
        if not column:
            raise HTTPException(status_code=400, detail="请指定要预览的列")

        # 预览清洗效果
        preview_result = enhanced_cleaner.preview_cleaning_effect(data, config, column) # Pass generic data

        return preview_result

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"预览清洗效果失败: {str(e)}")


@app.post("/api/data/{data_id}/enhanced-clean") # Renamed endpoint and parameter
async def enhanced_clean_data(data_id: str, config: dict): # Renamed function and parameter
    """增强数据清洗"""
    try:
        # 加载数据
        data = data_processor.load_patient_data(data_id) # load_patient_data now loads generic data
        if not data:
            raise HTTPException(status_code=404, detail="数据未找到")

        # 使用增强清洗器
        result = enhanced_cleaner.clean_data(data, config) # Pass generic data

        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"增强数据清洗失败: {str(e)}")


# Set the schema_service instance for the router's dependency
schema_router._schema_service_instance = schema_service

# Include schema router
app.include_router(schema_router.router, prefix="/api/schemas", tags=["Schemas"])

@app.post("/api/data/confirm", response_model=ConfirmedDataResponse)
async def confirm_data_endpoint(request: DataConfirmRequest):
    """确认数据"""
    try:
        success = data_processor.mark_data_as_confirmed(request.data_ids)
        if not success:
            raise HTTPException(status_code=500, detail="未能确认所有数据。")
        
        return ConfirmedDataResponse(
            success=True,
            message="数据确认成功",
            confirmed_data_ids=request.data_ids
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据确认失败: {str(e)}")


@app.post("/api/data/process-format", response_model=DataFormatResponse)
async def format_data_endpoint(request: DataFormatRequest):
    """格式化数据，包括转换为有表头数据、应用模式和保存新版本"""
    try:
        formatted_ids = await data_processor.format_data(
            data_ids=request.data_ids,
            convert_to_headered=request.convert_to_headered,
            schema_id=request.schema_id,
            value_column_name=request.value_column_name
        )
        return DataFormatResponse(
            success=True,
            message=f"成功格式化 {len(formatted_ids)} 条数据。",
            formatted_data_ids=formatted_ids
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"数据格式化失败: {str(e)}")

# Temporary test endpoint for schema loading
@app.get("/api/test-schemas", response_model=List[DataSchemaResponse])
async def test_schemas_endpoint():
    try:
        print("DEBUG: test_schemas_endpoint called directly.")
        return schema_service.get_schemas()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"测试获取数据模式失败: {str(e)}")

# Brand new test POST endpoint
@app.post("/api/test-post")
async def test_post_endpoint():
    print("DEBUG: test_post_endpoint called.")
    return {"message": "POST request received successfully!"}

@app.post("/api/data/delete-batch", response_model=DataDeleteBatchResponse)
async def delete_data_batch_endpoint(request: DataDeleteBatchRequest):
    """批量删除数据"""
    try:
        deleted_ids = data_processor.delete_data_batch(request.data_ids)
        return DataDeleteBatchResponse(
            success=True,
            message=f"成功删除 {len(deleted_ids)} 条数据。",
            deleted_data_ids=deleted_ids
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"批量删除失败: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
