from pydantic import BaseModel
from typing import List, Dict, Any, Optional


class DataUploadResponse(BaseModel):
    success: bool
    message: str
    patient_count: int # For zip, or 1 for single csv
    file_info: Dict[str, Any]


class GenericDataResponse(BaseModel):
    data_id: str
    columns: List[str]
    data: List[Dict[str, Any]]
    shape: List[int]
    summary: Dict[str, Any]
    records: int


class FeatureExtractionRequest(BaseModel):
    data_id: str
    feature_config: Dict[str, List[str]]


class MLTrainRequest(BaseModel):
    data_id: str # Add data_id
    model_type: str
    features: List[str] # This will now be derived from the feature file for the data_id
    target: str
    model_params: Dict[str, Any] = {}


class MLPredictRequest(BaseModel):
    model_id: str
    features: Dict[str, Any]


class CleaningConfig(BaseModel):
    remove_outliers: bool = True
    outlier_method: str = "iqr"
    fill_missing: bool = True
    missing_method: str = "interpolate"
    smooth_data: bool = False
    smooth_window: int = 5


class ColumnDefinition(BaseModel):
    name: str
    type: str # e.g., "string", "number", "datetime", "boolean"
    # Add other properties like description, required, etc. if needed

class DataSchemaBase(BaseModel):
    name: str
    description: Optional[str] = None
    schema_type: str = "standard" # "standard" or "high_frequency_wide"
    
    # For "standard" schema_type
    columns: Optional[List[ColumnDefinition]] = None 
    
    # For "high_frequency_wide" schema_type
    time_column_index: Optional[int] = None # e.g., 0
    data_start_column_index: Optional[int] = None # e.g., 1
    num_data_columns: Optional[int] = None # e.g., 50
    data_column_base_name: Optional[str] = None # e.g., "value"
    sampling_rate_hz: Optional[float] = None # e.g., 50.0

class DataSchemaCreate(DataSchemaBase):
    pass

class DataSchemaResponse(DataSchemaBase):
    id: str
    created_at: Optional[str] = None # Store as ISO string
    updated_at: Optional[str] = None # Store as ISO string

class DataSchemaUpdate(BaseModel): # Allow partial updates
    name: Optional[str] = None
    description: Optional[str] = None
    schema_type: Optional[str] = None
    columns: Optional[List[ColumnDefinition]] = None
    time_column_index: Optional[int] = None
    data_start_column_index: Optional[int] = None
    num_data_columns: Optional[int] = None
    data_column_base_name: Optional[str] = None
    sampling_rate_hz: Optional[float] = None

class DataConfirmRequest(BaseModel):
    data_ids: List[str]

class ConfirmedDataResponse(BaseModel):
    success: bool
    message: str
    confirmed_data_ids: List[str]

class DataFormatRequest(BaseModel):
    data_ids: List[str]
    convert_to_headered: bool = False
    schema_id: Optional[str] = None
    value_column_name: Optional[str] = None # For high_frequency_wide transformation

class DataFormatResponse(BaseModel):
    success: bool
    message: str
    formatted_data_ids: List[str]

class DataDeleteBatchRequest(BaseModel):
    data_ids: List[str]

class DataDeleteBatchResponse(BaseModel):
    success: bool
    message: str
    deleted_data_ids: List[str]
