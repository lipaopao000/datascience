# 医疗数据分析平台

基于Vue3前端和Python FastAPI后端的医疗数据分析平台，支持ECG和MV数据的处理、可视化、特征提取和机器学习分析。

## 项目结构

```
datascience/
├── backend/                    # Python后端
│   ├── main.py                # FastAPI主应用
│   ├── models/                # 数据模型
│   │   └── schemas.py         # Pydantic模型定义
│   ├── services/              # 业务逻辑服务
│   │   ├── data_processor.py  # 数据处理服务
│   │   ├── data_cleaner.py    # 数据清洗服务
│   │   ├── feature_extractor.py # 特征提取服务
│   │   └── ml_service.py      # 机器学习服务
│   ├── data/                  # 数据目录
│   │   ├── processed/         # 处理后的数据
│   │   ├── features/          # 提取的特征
│   │   └── models/            # 训练的模型
│   └── requirements.txt       # Python依赖
├── frontend/                  # Vue3前端
│   ├── src/
│   │   ├── main.js           # 应用入口
│   │   ├── App.vue           # 根组件
│   │   ├── router/           # 路由配置
│   │   ├── api/              # API接口
│   │   ├── components/       # 公共组件
│   │   └── views/            # 页面组件
│   │       ├── Dashboard.vue # 仪表板
│   │       ├── data/         # 数据管理
│   │       ├── analysis/     # 数据分析
│   │       └── ml/           # 机器学习
│   ├── package.json          # 前端依赖
│   └── vite.config.js        # Vite配置
├── ecg_analysis.py           # 原始ECG分析程序
├── mv_analysis.py            # 原始MV分析程序
├── data_visualization.py     # 原始可视化程序
└── README.md                 # 项目说明
```

## 功能特性

### 数据管理
- **数据导入**: 支持CSV、Excel等格式的医疗数据导入
- **数据列表**: 查看和管理已导入的患者数据
- **数据清洗**: 缺失值处理、异常值检测、数据标准化

### 数据分析
- **数据可视化**: 时间序列图、散点图、箱线图、热力图等
- **特征工程**: 统计特征、时序特征、频域特征提取
- **统计分析**: 描述性统计、相关性分析

### 机器学习
- **模型训练**: 支持多种算法（随机森林、SVM、神经网络等）
- **模型管理**: 模型版本管理、性能对比
- **模型预测**: 使用训练好的模型进行预测
- **模型评估**: 性能指标、混淆矩阵、ROC曲线

## 技术栈

### 后端
- **FastAPI**: 现代、快速的Web框架
- **Pandas**: 数据处理和分析
- **NumPy**: 数值计算
- **Scikit-learn**: 机器学习算法
- **Plotly**: 交互式图表
- **Uvicorn**: ASGI服务器

### 前端
- **Vue 3**: 渐进式JavaScript框架
- **Element Plus**: Vue 3组件库
- **ECharts**: 数据可视化图表库
- **Axios**: HTTP客户端
- **Vue Router**: 路由管理
- **Vite**: 构建工具

## 快速开始

### 环境要求
- Python 3.8+
- Node.js 16+
- npm 或 yarn

### 后端启动

1. 安装Python依赖：
```bash
cd backend
pip install -r requirements.txt
```

2. 启动后端服务：
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

3. 访问API文档：http://localhost:8000/docs

### 前端启动

1. 安装前端依赖：
```bash
cd frontend
npm install
```

2. 启动开发服务器：
```bash
npm run dev
```

3. 访问前端应用：http://localhost:3001

## API接口

### 数据管理
- `GET /api/patients` - 获取患者列表
- `POST /api/upload` - 上传数据文件
- `GET /api/patients/{patient_id}` - 获取患者数据
- `POST /api/patients/{patient_id}/clean` - 清洗患者数据

### 数据分析
- `GET /api/patients/{patient_id}/visualization/{data_type}` - 获取可视化数据
- `POST /api/features/extract` - 提取特征
- `GET /api/features` - 获取特征列表

### 机器学习
- `POST /api/ml/train` - 训练模型
- `GET /api/ml/models` - 获取模型列表
- `POST /api/ml/predict` - 模型预测
- `GET /api/ml/models/{model_id}/evaluate` - 模型评估

## 数据格式

### ECG数据格式
```csv
timestamp,lead_I,lead_II,lead_III,aVR,aVL,aVF,V1,V2,V3,V4,V5,V6
2023-01-01 00:00:00,0.1,0.2,0.1,-0.15,0.05,0.15,0.3,0.5,0.8,1.2,1.0,0.6
```

### MV数据格式
```csv
timestamp,FiO2,frequency,target_volume,PEEP,pressure,flow
2023-01-01 00:00:00,0.21,12,500,5,15,0.5
```

## 服务状态

### 当前运行状态
- **后端服务**: ✅ 运行中 (http://localhost:8000)
- **前端服务**: ✅ 运行中 (http://localhost:3001)
- **API文档**: ✅ 可访问 (http://localhost:8000/docs)

### 已完成功能
- ✅ 后端API架构搭建
- ✅ 数据处理服务
- ✅ 数据清洗服务
- ✅ 特征提取服务
- ✅ 机器学习服务
- ✅ Vue3前端框架
- ✅ 主要页面组件
- ✅ 路由配置
- ✅ API接口集成

### 开发中功能
- 🔄 数据上传功能完善
- 🔄 图表交互优化
- 🔄 模型管理界面
- 🔄 用户权限系统

## 原始程序

项目保留了原始的3个Python程序：
- `ecg_analysis.py` - ECG数据分析（Tkinter GUI）
- `mv_analysis.py` - 机械通气数据分析
- `data_visualization.py` - 数据可视化工具

这些程序已被重构为现代化的Web应用架构。